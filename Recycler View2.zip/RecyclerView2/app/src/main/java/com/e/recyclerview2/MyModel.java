package com.e.recyclerview2;

public class MyModel {

    public MyModel(String maintitle){
        // this.maintitle=maintitle;
        setMaintitle( maintitle );
    }

    public String getMaintitle() {
        return maintitle;
    }

    public void setMaintitle(String maintitle) {
        this.maintitle = maintitle;
    }

    private String maintitle;
}
